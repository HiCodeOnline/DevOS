// Package notes 提供类 Notion 的笔记应用：页面树、块编辑器、搜索、收藏与回收站。
package notes

import (
	"crypto/rand"
	"database/sql"
	"embed"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"html"
	"io"
	"io/fs"
	"log/slog"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"sync"
	"time"
	"unicode/utf8"

	"github.com/gofiber/fiber/v2"

	"devos/internal/plugin"
	"devos/internal/secure"
	"devos/internal/sqlstore"
)

//go:embed web
var webFS embed.FS

const (
	maxPages           = 5000
	maxBlocksPerPage   = 600
	maxContentRunes    = 20000
	maxImageBytes      = 10 << 20
	maxAudioBytes      = 40 << 20
	maxVideoBytes      = 60 << 20
	maxAttachmentBytes = 40 << 20
	maxSearchResults   = 50
)

// 支持的块类型，与前端编辑器保持一致。
var blockTypes = map[string]bool{
	"paragraph": true, "heading1": true, "heading2": true, "heading3": true,
	"bulleted": true, "numbered": true, "todo": true, "toggle": true,
	"quote": true, "callout": true, "code": true, "divider": true,
	"image": true, "bookmark": true, "table": true,
	"equation": true, "diagram": true,
	"audio": true, "video": true, "file": true,
}

var blockColors = map[string]bool{
	"default": true, "gray": true, "brown": true, "orange": true,
	"yellow": true, "green": true, "blue": true, "purple": true,
	"pink": true, "red": true,
}

var imageExts = map[string]bool{
	".png": true, ".jpg": true, ".jpeg": true, ".gif": true, ".webp": true, ".bmp": true,
}

var audioExts = map[string]bool{
	".mp3": true, ".wav": true, ".ogg": true, ".m4a": true, ".aac": true, ".flac": true, ".opus": true,
}

var videoExts = map[string]bool{
	".mp4": true, ".webm": true, ".ogv": true, ".mov": true, ".m4v": true,
}

// 附件只接受文档类扩展名，避免 HTML/SVG 等可执行内容带来安全风险。
var attachmentExts = map[string]bool{
	".pdf": true, ".txt": true, ".md": true, ".csv": true, ".json": true,
	".zip": true, ".rar": true, ".7z": true, ".epub": true,
	".doc": true, ".docx": true, ".xls": true, ".xlsx": true, ".ppt": true, ".pptx": true,
}

// 上传类型到存储子目录的映射，按类型与年月分层，便于迁移与备份。
var uploadDirs = map[string]string{
	"image": "images",
	"audio": "audio",
	"video": "video",
	"file":  "attachments",
}

func uploadLimit(kind string) int64 {
	switch kind {
	case "image":
		return maxImageBytes
	case "audio":
		return maxAudioBytes
	case "video":
		return maxVideoBytes
	default:
		return maxAttachmentBytes
	}
}

func extAllowed(kind, ext string) bool {
	switch kind {
	case "image":
		return imageExts[ext]
	case "audio":
		return audioExts[ext]
	case "video":
		return videoExts[ext]
	default:
		return attachmentExts[ext]
	}
}

func detectKind(ext, mime string) string {
	switch {
	case imageExts[ext], strings.HasPrefix(mime, "image/"):
		return "image"
	case audioExts[ext], strings.HasPrefix(mime, "audio/"):
		return "audio"
	case videoExts[ext], strings.HasPrefix(mime, "video/"):
		return "video"
	default:
		return "file"
	}
}

// BlockProps 保存不同块类型的附加属性。
type BlockProps struct {
	Checked   bool       `json:"checked,omitempty"`
	Collapsed bool       `json:"collapsed,omitempty"`
	Language  string     `json:"language,omitempty"`
	Icon      string     `json:"icon,omitempty"`
	Color     string     `json:"color,omitempty"`
	URL       string     `json:"url,omitempty"`
	Caption   string     `json:"caption,omitempty"`
	Rows      [][]string `json:"rows,omitempty"`
	HasHeader bool       `json:"hasHeader,omitempty"`
}

// Block 是页面中的一个内容块。
type Block struct {
	ID      string     `json:"id"`
	Type    string     `json:"type"`
	Content string     `json:"content"`
	Props   BlockProps `json:"props"`
}

// Page 是一个笔记页面，支持无限层级嵌套；Folder 为真时作为文件夹收纳子页面。
type Page struct {
	ID        string  `json:"id"`
	ParentID  string  `json:"parentId"`
	Title     string  `json:"title"`
	Icon      string  `json:"icon"`
	Cover     string  `json:"cover"`
	Folder    bool    `json:"folder,omitempty"`
	Favorite  bool    `json:"favorite"`
	Trashed   bool    `json:"trashed"`
	TrashedAt string  `json:"trashedAt"`
	Order     int     `json:"order"`
	Blocks    []Block `json:"blocks"`
	CreatedAt string  `json:"createdAt"`
	UpdatedAt string  `json:"updatedAt"`
}

// PageSummary 是侧边栏与搜索结果使用的页面摘要（不含块内容）。
type PageSummary struct {
	ID         string `json:"id"`
	ParentID   string `json:"parentId"`
	Title      string `json:"title"`
	Icon       string `json:"icon"`
	Cover      string `json:"cover"`
	Folder     bool   `json:"folder,omitempty"`
	Favorite   bool   `json:"favorite"`
	Trashed    bool   `json:"trashed"`
	TrashedAt  string `json:"trashedAt"`
	Order      int    `json:"order"`
	BlockCount int    `json:"blockCount"`
	Preview    string `json:"preview"`
	CreatedAt  string `json:"createdAt"`
	UpdatedAt  string `json:"updatedAt"`
}

// Workspace 是全部笔记数据。
type Workspace struct {
	Pages []Page `json:"pages"`
}

// SearchResult 是一条搜索结果。
type SearchResult struct {
	ID        string `json:"id"`
	Title     string `json:"title"`
	Icon      string `json:"icon"`
	Snippet   string `json:"snippet"`
	Match     string `json:"match"` // title | content
	UpdatedAt string `json:"updatedAt"`
}

type API struct {
	mu       sync.RWMutex
	ws       Workspace
	db       *sql.DB
	filesDir string
	keys     *secure.Keyring
	log      *slog.Logger
}

var noteMigrations = []string{`
CREATE TABLE pages (
	id         TEXT PRIMARY KEY,
	parent_id  TEXT NOT NULL DEFAULT '',
	title      TEXT NOT NULL DEFAULT '',
	icon       TEXT NOT NULL DEFAULT '',
	cover      TEXT NOT NULL DEFAULT '',
	folder     INTEGER NOT NULL DEFAULT 0,
	favorite   INTEGER NOT NULL DEFAULT 0,
	trashed    INTEGER NOT NULL DEFAULT 0,
	trashed_at TEXT NOT NULL DEFAULT '',
	ord        INTEGER NOT NULL DEFAULT 0,
	created_at TEXT NOT NULL DEFAULT '',
	updated_at TEXT NOT NULL DEFAULT ''
);
CREATE INDEX idx_pages_parent ON pages(parent_id, ord);
CREATE TABLE blocks (
	page_id    TEXT NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
	id         TEXT NOT NULL,
	ord        INTEGER NOT NULL DEFAULT 0,
	type       TEXT NOT NULL DEFAULT 'paragraph',
	content    TEXT NOT NULL DEFAULT '',
	props_json TEXT NOT NULL DEFAULT '{}',
	PRIMARY KEY (page_id, id)
);
CREATE INDEX idx_blocks_page ON blocks(page_id, ord);
`}

const (
	pageColumns = `id, parent_id, title, icon, cover, folder, favorite, trashed,
	trashed_at, ord, created_at, updated_at`

	upsertPage = `INSERT INTO pages (` + pageColumns + `)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
ON CONFLICT(id) DO UPDATE SET
	parent_id = excluded.parent_id, title = excluded.title, icon = excluded.icon,
	cover = excluded.cover, folder = excluded.folder, favorite = excluded.favorite,
	trashed = excluded.trashed, trashed_at = excluded.trashed_at, ord = excluded.ord,
	created_at = excluded.created_at, updated_at = excluded.updated_at`

	insertBlock = `INSERT INTO blocks (page_id, id, ord, type, content, props_json)
VALUES (?, ?, ?, ?, ?, ?)`
)

func New() *API { return &API{} }

func (p *API) Manifest() plugin.Manifest {
	return plugin.Manifest{
		ID:          "notes",
		Name:        "笔记",
		Description: "类 Notion 的块编辑器，支持页面树、搜索、收藏与 Markdown 导入导出",
		Version:     "1.0.0",
		Category:    "效率",
		Icon:        `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h8l4 4v14a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z"/><path d="M14 3v4h4"/><path d="M9 12h6M9 16h6M9 8h2"/></svg>`,
		Accent:      "#d97706",
		Entry:       "index.html",
		Width:       1280,
		Height:      820,
		Multi:       false,
		Builtin:     true,
		Backend:     true,
	}
}

func (p *API) Init(ctx *plugin.Context) error {
	p.filesDir = filepath.Join(ctx.DataDir, "files")
	p.log = ctx.Logger
	if err := os.MkdirAll(p.filesDir, 0o755); err != nil {
		return fmt.Errorf("创建附件目录失败: %w", err)
	}
	keys, err := secure.Open(ctx.DataDir, "notes.key")
	if err != nil {
		return fmt.Errorf("初始化加密密钥失败: %w", err)
	}
	p.keys = keys
	db, err := sqlstore.Open(ctx.DataDir, "notes.db", noteMigrations)
	if err != nil {
		return fmt.Errorf("打开笔记数据库失败: %w", err)
	}
	p.db = db
	if err := p.migrateLegacy(filepath.Join(ctx.DataDir, "notes.json")); err != nil {
		return err
	}
	if err := p.loadWorkspace(); err != nil {
		return err
	}
	p.normalizeWorkspace()
	return nil
}

// Close 关闭笔记数据库，主要供测试与插件卸载使用。
func (p *API) Close() error {
	return p.db.Close()
}

func (p *API) Assets() fs.FS {
	sub, _ := fs.Sub(webFS, "web")
	return sub
}

func (p *API) Register(api fiber.Router) {
	api.Get("/workspace", p.handleWorkspace)
	api.Get("/search", p.handleSearch)
	api.Post("/pages", p.handleCreatePage)
	api.Get("/pages/:id", p.handleGetPage)
	api.Put("/pages/:id", p.handleSavePage)
	api.Delete("/pages/:id", p.handleDeletePage)
	api.Post("/pages/:id/favorite", p.handleFavorite)
	api.Post("/pages/:id/move", p.handleMove)
	api.Post("/pages/:id/trash", p.handleTrash)
	api.Post("/pages/:id/restore", p.handleRestore)
	api.Post("/pages/:id/duplicate", p.handleDuplicate)
	api.Get("/pages/:id/export", p.handleExport)
	api.Delete("/trash", p.handleEmptyTrash)
	api.Post("/upload", p.handleUpload)
	api.Get("/files/*", p.handleFile)
}

func (p *API) handleWorkspace(c *fiber.Ctx) error {
	c.Set("Cache-Control", "no-store")
	p.mu.RLock()
	defer p.mu.RUnlock()
	pages := make([]PageSummary, 0, len(p.ws.Pages))
	for _, page := range sortedPages(p.ws.Pages) {
		pages = append(pages, summarize(page))
	}
	return c.JSON(fiber.Map{"pages": pages})
}

func (p *API) handleGetPage(c *fiber.Ctx) error {
	c.Set("Cache-Control", "no-store")
	p.mu.RLock()
	defer p.mu.RUnlock()
	page := p.findPage(c.Params("id"))
	if page == nil {
		return fiber.NewError(fiber.StatusNotFound, "页面不存在")
	}
	return c.JSON(page)
}

type createInput struct {
	ParentID string  `json:"parentId"`
	Title    string  `json:"title"`
	Icon     string  `json:"icon"`
	Cover    string  `json:"cover"`
	Folder   bool    `json:"folder"`
	Blocks   []Block `json:"blocks"`
}

func (p *API) handleCreatePage(c *fiber.Ctx) error {
	var in createInput
	if err := c.BodyParser(&in); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "参数解析失败")
	}
	p.mu.Lock()
	if len(p.ws.Pages) >= maxPages {
		p.mu.Unlock()
		return fiber.NewError(fiber.StatusBadRequest, "页面数量已达上限")
	}
	parent := strings.TrimSpace(in.ParentID)
	if parent != "" {
		if target := p.findPage(parent); target == nil || target.Trashed {
			parent = ""
		}
	}
	now := time.Now().Format(time.RFC3339)
	page := Page{
		ID:        newID(),
		ParentID:  parent,
		Title:     normalizeTitle(in.Title),
		Icon:      normalizeIcon(in.Icon),
		Cover:     normalizeCover(in.Cover),
		Folder:    in.Folder,
		Order:     p.nextOrder(parent),
		Blocks:    normalizeBlocks(in.Blocks),
		CreatedAt: now,
		UpdatedAt: now,
	}
	if page.Folder {
		// 文件夹主要收纳子页面，块内容保留为空段落以便后续转为普通页面。
		page.Blocks = normalizeBlocks(nil)
	}
	p.ws.Pages = append(p.ws.Pages, page)
	p.mu.Unlock()
	if err := p.savePages(page); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, err.Error())
	}
	return c.Status(fiber.StatusCreated).JSON(page)
}

type saveInput struct {
	Title  *string  `json:"title"`
	Icon   *string  `json:"icon"`
	Cover  *string  `json:"cover"`
	Folder *bool    `json:"folder"`
	Blocks *[]Block `json:"blocks"`
}

func (p *API) handleSavePage(c *fiber.Ctx) error {
	var in saveInput
	if err := c.BodyParser(&in); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "参数解析失败")
	}
	p.mu.Lock()
	page := p.findPage(c.Params("id"))
	if page == nil {
		p.mu.Unlock()
		return fiber.NewError(fiber.StatusNotFound, "页面不存在")
	}
	if in.Title != nil {
		page.Title = normalizeTitle(*in.Title)
	}
	if in.Icon != nil {
		page.Icon = normalizeIcon(*in.Icon)
	}
	if in.Cover != nil {
		page.Cover = normalizeCover(*in.Cover)
	}
	if in.Folder != nil {
		page.Folder = *in.Folder
	}
	if in.Blocks != nil {
		page.Blocks = normalizeBlocks(*in.Blocks)
	}
	if page.Folder {
		page.Blocks = normalizeBlocks(nil)
	}
	page.UpdatedAt = time.Now().Format(time.RFC3339)
	result := *page
	p.mu.Unlock()
	if err := p.savePages(result); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, err.Error())
	}
	return c.JSON(result)
}

func (p *API) handleFavorite(c *fiber.Ctx) error {
	var in struct {
		Value *bool `json:"value"`
	}
	_ = c.BodyParser(&in)
	p.mu.Lock()
	page := p.findPage(c.Params("id"))
	if page == nil {
		p.mu.Unlock()
		return fiber.NewError(fiber.StatusNotFound, "页面不存在")
	}
	if in.Value != nil {
		page.Favorite = *in.Value
	} else {
		page.Favorite = !page.Favorite
	}
	page.UpdatedAt = time.Now().Format(time.RFC3339)
	result := *page
	p.mu.Unlock()
	if err := p.savePages(result); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, err.Error())
	}
	return c.JSON(fiber.Map{"ok": true})
}

func (p *API) handleMove(c *fiber.Ctx) error {
	var in struct {
		ParentID string `json:"parentId"`
		Index    int    `json:"index"`
	}
	if err := c.BodyParser(&in); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "参数解析失败")
	}
	p.mu.Lock()
	page := p.findPage(c.Params("id"))
	if page == nil {
		p.mu.Unlock()
		return fiber.NewError(fiber.StatusNotFound, "页面不存在")
	}
	parent := strings.TrimSpace(in.ParentID)
	if parent == page.ID {
		p.mu.Unlock()
		return fiber.NewError(fiber.StatusBadRequest, "页面不能移动到自身之下")
	}
	if parent != "" {
		target := p.findPage(parent)
		if target == nil || target.Trashed {
			p.mu.Unlock()
			return fiber.NewError(fiber.StatusBadRequest, "目标页面不可用")
		}
		if p.isDescendant(parent, page.ID) {
			p.mu.Unlock()
			return fiber.NewError(fiber.StatusBadRequest, "页面不能移动到自身的子页面之下")
		}
	}
	oldParent := page.ParentID
	list := p.siblings(parent, page.ID)
	index := in.Index
	if index < 0 || index > len(list) {
		index = len(list)
	}
	list = append(list, nil)
	copy(list[index+1:], list[index:])
	list[index] = page
	page.ParentID = parent
	stamp := nowString()
	for i, sibling := range list {
		if sibling != nil {
			sibling.Order = i
			sibling.UpdatedAt = stamp
		}
	}
	if oldParent != parent {
		p.reindex(oldParent)
	}
	affected := make([]Page, 0, len(list)+8)
	seen := make(map[string]bool, len(list)+8)
	collect := func(items []*Page) {
		for _, item := range items {
			if item == nil || seen[item.ID] {
				continue
			}
			seen[item.ID] = true
			affected = append(affected, *item)
		}
	}
	collect(list)
	collect(p.siblings(parent, ""))
	collect(p.siblings(oldParent, ""))
	p.mu.Unlock()
	if err := p.savePages(affected...); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, err.Error())
	}
	return c.JSON(fiber.Map{"ok": true})
}

func (p *API) handleTrash(c *fiber.Ctx) error {
	p.mu.Lock()
	page := p.findPage(c.Params("id"))
	if page == nil {
		p.mu.Unlock()
		return fiber.NewError(fiber.StatusNotFound, "页面不存在")
	}
	stamp := nowString()
	affected := make([]Page, 0, 4)
	for _, id := range p.subtreeIDs(page.ID) {
		if item := p.findPage(id); item != nil {
			item.Trashed = true
			item.TrashedAt = stamp
			item.Favorite = false
			affected = append(affected, *item)
		}
	}
	p.mu.Unlock()
	if err := p.savePages(affected...); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, err.Error())
	}
	return c.JSON(fiber.Map{"ok": true})
}

func (p *API) handleRestore(c *fiber.Ctx) error {
	p.mu.Lock()
	page := p.findPage(c.Params("id"))
	if page == nil {
		p.mu.Unlock()
		return fiber.NewError(fiber.StatusNotFound, "页面不存在")
	}
	parent := p.findPage(page.ParentID)
	if page.ParentID != "" && (parent == nil || parent.Trashed) {
		page.ParentID = ""
		page.Order = p.nextOrder("")
	}
	affected := make([]Page, 0, 4)
	for _, id := range p.subtreeIDs(page.ID) {
		if item := p.findPage(id); item != nil {
			item.Trashed = false
			item.TrashedAt = ""
			affected = append(affected, *item)
		}
	}
	p.mu.Unlock()
	if err := p.savePages(affected...); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, err.Error())
	}
	return c.JSON(fiber.Map{"ok": true})
}

func (p *API) handleDuplicate(c *fiber.Ctx) error {
	var in struct {
		Title string `json:"title"`
	}
	_ = c.BodyParser(&in)
	p.mu.Lock()
	page := p.findPage(c.Params("id"))
	if page == nil {
		p.mu.Unlock()
		return fiber.NewError(fiber.StatusNotFound, "页面不存在")
	}
	if len(p.ws.Pages)+len(p.subtreeIDs(page.ID)) > maxPages {
		p.mu.Unlock()
		return fiber.NewError(fiber.StatusBadRequest, "页面数量已达上限")
	}
	ids := p.subtreeIDs(page.ID)
	now := nowString()
	mapping := make(map[string]string, len(ids))
	for _, id := range ids {
		mapping[id] = newID()
	}
	// 原页面之后的同级页面顺延，让副本紧跟在原页面之后。
	for _, sibling := range p.siblings(page.ParentID, "") {
		if sibling.Order > page.Order {
			sibling.Order++
		}
	}
	copied := make([]Page, 0, len(ids))
	for _, id := range ids {
		source := p.findPage(id)
		if source == nil {
			continue
		}
		target := *source
		target.ID = mapping[id]
		target.Favorite = false
		target.Trashed = false
		target.TrashedAt = ""
		target.CreatedAt = now
		target.UpdatedAt = now
		target.Blocks = cloneBlocks(source.Blocks)
		if id == page.ID {
			if title := strings.TrimSpace(in.Title); title != "" {
				target.Title = normalizeTitle(title)
			} else {
				target.Title = normalizeTitle(source.Title + " (copy)")
			}
			target.Order = page.Order + 1
		}
		if next, ok := mapping[source.ParentID]; ok {
			target.ParentID = next
		} else {
			target.ParentID = source.ParentID
		}
		copied = append(copied, target)
	}
	cache := make(map[string]string)
	for i := range copied {
		// 副本独立持有附件，避免删除任一页面时误删另一份引用的文件。
		p.remapAssets(&copied[i], cache)
	}
	p.ws.Pages = append(p.ws.Pages, copied...)
	p.reindex(page.ParentID)
	rootID := mapping[page.ID]
	affected := append([]Page{}, copied...)
	for _, sibling := range p.siblings(page.ParentID, "") {
		affected = append(affected, *sibling)
	}
	p.mu.Unlock()
	if err := p.savePages(affected...); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, err.Error())
	}
	return c.JSON(fiber.Map{"ok": true, "pageId": rootID})
}

func (p *API) handleDeletePage(c *fiber.Ctx) error {
	p.mu.Lock()
	page := p.findPage(c.Params("id"))
	if page == nil {
		p.mu.Unlock()
		return fiber.NewError(fiber.StatusNotFound, "页面不存在")
	}
	ids := p.subtreeIDs(page.ID)
	remove := make(map[string]bool, len(ids))
	var files []string
	for _, id := range ids {
		remove[id] = true
		if item := p.findPage(id); item != nil {
			files = append(files, pageFiles(*item)...)
		}
	}
	out := p.ws.Pages[:0]
	for _, item := range p.ws.Pages {
		if !remove[item.ID] {
			out = append(out, item)
		}
	}
	p.ws.Pages = out
	p.reindex(page.ParentID)
	p.mu.Unlock()
	for _, name := range files {
		_ = os.Remove(filepath.Join(p.filesDir, filepath.FromSlash(name)))
	}
	if err := p.deletePages(ids); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, err.Error())
	}
	return c.JSON(fiber.Map{"ok": true})
}

func (p *API) handleEmptyTrash(c *fiber.Ctx) error {
	p.mu.Lock()
	var files []string
	var ids []string
	out := p.ws.Pages[:0]
	for _, page := range p.ws.Pages {
		if page.Trashed {
			files = append(files, pageFiles(page)...)
			ids = append(ids, page.ID)
			continue
		}
		out = append(out, page)
	}
	p.ws.Pages = out
	p.mu.Unlock()
	for _, name := range files {
		_ = os.Remove(filepath.Join(p.filesDir, filepath.FromSlash(name)))
	}
	if err := p.deletePages(ids); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, err.Error())
	}
	return c.JSON(fiber.Map{"ok": true})
}

func (p *API) handleSearch(c *fiber.Ctx) error {
	query := strings.TrimSpace(c.Query("q"))
	c.Set("Cache-Control", "no-store")
	if query == "" {
		return c.JSON([]SearchResult{})
	}
	lower := strings.ToLower(query)
	p.mu.RLock()
	defer p.mu.RUnlock()
	results := make([]SearchResult, 0, 16)
	for _, page := range sortedPages(p.ws.Pages) {
		if page.Trashed {
			continue
		}
		item := SearchResult{ID: page.ID, Title: page.Title, Icon: page.Icon, UpdatedAt: page.UpdatedAt}
		if strings.Contains(strings.ToLower(page.Title), lower) {
			item.Match = "title"
			item.Snippet = summarize(page).Preview
			results = append(results, item)
			if len(results) >= maxSearchResults {
				break
			}
			continue
		}
		for _, block := range page.Blocks {
			text := blockPlainText(block)
			if text == "" || !strings.Contains(strings.ToLower(text), lower) {
				continue
			}
			item.Match = "content"
			item.Snippet = makeSnippet(text, query)
			results = append(results, item)
			break
		}
		if len(results) >= maxSearchResults {
			break
		}
	}
	return c.JSON(results)
}

func (p *API) handleExport(c *fiber.Ctx) error {
	p.mu.RLock()
	page := p.findPage(c.Params("id"))
	if page == nil {
		p.mu.RUnlock()
		return fiber.NewError(fiber.StatusNotFound, "页面不存在")
	}
	content := exportMarkdown(*page)
	title := page.Title
	if title == "" {
		title = "Untitled"
	}
	p.mu.RUnlock()
	filename := safeFilename(title) + ".md"
	c.Set("Content-Type", "text/markdown; charset=utf-8")
	c.Set("Content-Disposition", `attachment; filename="note.md"; filename*=UTF-8''`+encodeFilename(filename))
	return c.SendString(content)
}

func (p *API) handleUpload(c *fiber.Ctx) error {
	file, err := c.FormFile("file")
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "未收到上传文件")
	}
	ext := strings.ToLower(filepath.Ext(file.Filename))
	kind := strings.ToLower(strings.TrimSpace(c.FormValue("kind")))
	if _, ok := uploadDirs[kind]; !ok || !extAllowed(kind, ext) {
		kind = detectKind(ext, file.Header.Get("Content-Type"))
	}
	if file.Size <= 0 || file.Size > uploadLimit(kind) {
		return fiber.NewError(fiber.StatusBadRequest, "文件大小超出限制")
	}
	if !extAllowed(kind, ext) {
		return fiber.NewError(fiber.StatusBadRequest, "不支持的文件类型")
	}
	src, err := file.Open()
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "读取上传文件失败")
	}
	head := make([]byte, 512)
	n, _ := io.ReadFull(src, head)
	_ = src.Close()
	if kind == "image" && !strings.HasPrefix(http.DetectContentType(head[:n]), "image/") {
		return fiber.NewError(fiber.StatusBadRequest, "文件内容不是有效图片")
	}
	// 按类型与年月分层存储：files/images/202510/<id>.png、files/audio/…、files/attachments/…。
	rel := filepath.ToSlash(filepath.Join(uploadDirs[kind], time.Now().Format("200601"), newID()+ext))
	abs := filepath.Join(p.filesDir, filepath.FromSlash(rel))
	if err := os.MkdirAll(filepath.Dir(abs), 0o755); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "创建附件目录失败")
	}
	if err := c.SaveFile(file, abs); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "保存文件失败")
	}
	return c.JSON(fiber.Map{
		"url":  filesURL(rel),
		"kind": kind,
		"name": filepath.Base(file.Filename),
		"size": file.Size,
	})
}

var (
	// legacyFilePattern 兼容旧版本平铺在 files/ 下的图片文件名。
	legacyFilePattern = regexp.MustCompile(`^[a-f0-9]{16}\.(png|jpg|jpeg|gif|webp|bmp)$`)
	assetPathPattern  = regexp.MustCompile(`^(images|audio|video|attachments)/[0-9]{6}/[a-f0-9]{16}\.(png|jpg|jpeg|gif|webp|bmp|mp3|wav|ogg|m4a|aac|flac|opus|mp4|webm|ogv|mov|m4v|pdf|txt|md|csv|json|zip|rar|7z|epub|doc|docx|xls|xlsx|ppt|pptx)$`)
)

// fileNamePattern 保留给测试与历史路径校验使用。
var fileNamePattern = legacyFilePattern

func assetKind(rel string) (string, bool) {
	if legacyFilePattern.MatchString(rel) {
		return "images", true
	}
	if !assetPathPattern.MatchString(rel) {
		return "", false
	}
	return strings.SplitN(rel, "/", 2)[0], true
}

// assetRelPath 将附件 URL 归一化为相对 files/ 的路径，非本应用附件返回空串。
func assetRelPath(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return ""
	}
	value = strings.TrimPrefix(value, "/api/apps/notes/files/")
	value = strings.TrimPrefix(value, "files/")
	value = filepath.ToSlash(strings.TrimPrefix(value, "/"))
	if _, ok := assetKind(value); !ok {
		return ""
	}
	return value
}

func filesURL(rel string) string {
	return "/api/apps/notes/files/" + filepath.ToSlash(rel)
}

func (p *API) handleFile(c *fiber.Ctx) error {
	rel := filepath.ToSlash(strings.TrimPrefix(c.Params("*"), "/"))
	kind, ok := assetKind(rel)
	if !ok {
		return fiber.ErrNotFound
	}
	path := filepath.Join(p.filesDir, filepath.FromSlash(rel))
	if _, err := os.Stat(path); err != nil {
		return fiber.ErrNotFound
	}
	c.Set("Cache-Control", "public, max-age=31536000, immutable")
	c.Set("X-Content-Type-Options", "nosniff")
	if kind == "attachments" {
		c.Set("Content-Disposition", `attachment; filename="`+filepath.Base(rel)+`"`)
	}
	return c.SendFile(path)
}

// remapAssets 为副本复制附件并改写引用，保证每个页面独立持有自己的文件。
func (p *API) remapAssets(page *Page, cache map[string]string) {
	remap := func(url string) string {
		rel := assetRelPath(url)
		if rel == "" {
			return url
		}
		if next, ok := cache[rel]; ok {
			return filesURL(next)
		}
		dir := "images"
		if idx := strings.Index(rel, "/"); idx >= 0 {
			dir = rel[:idx]
		}
		next := filepath.ToSlash(filepath.Join(dir, time.Now().Format("200601"), newID()+strings.ToLower(filepath.Ext(rel))))
		data, err := os.ReadFile(filepath.Join(p.filesDir, filepath.FromSlash(rel)))
		if err != nil {
			return url
		}
		dst := filepath.Join(p.filesDir, filepath.FromSlash(next))
		if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
			return url
		}
		if err := os.WriteFile(dst, data, 0o644); err != nil {
			return url
		}
		cache[rel] = next
		return filesURL(next)
	}
	page.Cover = remap(page.Cover)
	for i := range page.Blocks {
		page.Blocks[i].Props.URL = remap(page.Blocks[i].Props.URL)
	}
}

// findPage 在已持锁的情况下按 ID 查找页面。
func (p *API) findPage(id string) *Page {
	for i := range p.ws.Pages {
		if p.ws.Pages[i].ID == id {
			return &p.ws.Pages[i]
		}
	}
	return nil
}

// siblings 返回同一层级下的页面（可按 ID 排除），保持现有顺序。
func (p *API) siblings(parentID, exclude string) []*Page {
	var out []*Page
	for i := range p.ws.Pages {
		page := &p.ws.Pages[i]
		if page.Trashed || page.ParentID != parentID || page.ID == exclude {
			continue
		}
		out = append(out, page)
	}
	sort.SliceStable(out, func(i, j int) bool {
		if out[i].Order == out[j].Order {
			return out[i].CreatedAt < out[j].CreatedAt
		}
		return out[i].Order < out[j].Order
	})
	return out
}

// reindex 重排某个层级下的顺序号。
func (p *API) reindex(parentID string) {
	for i, page := range p.siblings(parentID, "") {
		page.Order = i
	}
}

func (p *API) nextOrder(parentID string) int {
	out := p.siblings(parentID, "")
	if len(out) == 0 {
		return 0
	}
	return out[len(out)-1].Order + 1
}

// subtreeIDs 返回页面自身及全部后代的 ID。
func (p *API) subtreeIDs(root string) []string {
	children := make(map[string][]string)
	for _, page := range p.ws.Pages {
		children[page.ParentID] = append(children[page.ParentID], page.ID)
	}
	var out []string
	queue := []string{root}
	for len(queue) > 0 {
		id := queue[0]
		queue = queue[1:]
		out = append(out, id)
		queue = append(queue, children[id]...)
	}
	return out
}

// isDescendant 判断 candidate 是否为 ancestor 的后代。
func (p *API) isDescendant(candidate, ancestor string) bool {
	seen := map[string]bool{}
	current := candidate
	for current != "" && !seen[current] {
		seen[current] = true
		if current == ancestor {
			return true
		}
		page := p.findPage(current)
		if page == nil {
			return false
		}
		current = page.ParentID
	}
	return false
}

func (p *API) normalizeWorkspace() {
	if p.ws.Pages == nil {
		p.ws.Pages = []Page{}
	}
	// 去重并丢弃非法 ID，保证后续查找稳定。
	seen := make(map[string]bool, len(p.ws.Pages))
	pages := make([]Page, 0, len(p.ws.Pages))
	for _, page := range p.ws.Pages {
		if !validID(page.ID) || seen[page.ID] {
			page.ID = newID()
		}
		if seen[page.ID] {
			continue
		}
		seen[page.ID] = true
		page.Title = normalizeTitle(page.Title)
		page.Icon = normalizeIcon(page.Icon)
		page.Cover = normalizeCover(page.Cover)
		page.Blocks = normalizeBlocks(page.Blocks)
		if page.Folder {
			page.Blocks = normalizeBlocks(nil)
		}
		pages = append(pages, page)
		if len(pages) >= maxPages {
			break
		}
	}
	p.ws.Pages = pages
	// 父页面不存在或形成环时回退到根层级。
	for i := range p.ws.Pages {
		page := &p.ws.Pages[i]
		if page.ParentID == page.ID {
			page.ParentID = ""
			continue
		}
		if page.ParentID != "" && p.findPage(page.ParentID) == nil {
			page.ParentID = ""
		}
	}
	for i := range p.ws.Pages {
		page := &p.ws.Pages[i]
		current := page.ParentID
		for depth := 0; current != "" && depth < maxPages; depth++ {
			if current == page.ID {
				page.ParentID = ""
				break
			}
			parent := p.findPage(current)
			if parent == nil {
				page.ParentID = ""
				break
			}
			current = parent.ParentID
		}
	}
}

func normalizeBlocks(blocks []Block) []Block {
	if blocks == nil {
		blocks = []Block{}
	}
	if len(blocks) > maxBlocksPerPage {
		blocks = blocks[:maxBlocksPerPage]
	}
	out := make([]Block, 0, len(blocks)+1)
	seen := map[string]bool{}
	for _, block := range blocks {
		if !validID(block.ID) || seen[block.ID] {
			block.ID = newID()
		}
		seen[block.ID] = true
		if !blockTypes[block.Type] {
			block.Type = "paragraph"
		}
		block.Content = normalizeContent(block.Type, block.Content)
		block.Props = normalizeProps(block.Type, block.Props)
		out = append(out, block)
	}
	if len(out) == 0 {
		out = append(out, Block{ID: newID(), Type: "paragraph", Content: ""})
	}
	return out
}

func normalizeContent(blockType, content string) string {
	// 代码、分割线、公式与流程图的正文是原始源码，不做行内 HTML 清洗。
	if blockType == "code" || blockType == "divider" || blockType == "equation" || blockType == "diagram" {
		return truncateRunes(content, maxContentRunes)
	}
	if blockType == "audio" || blockType == "video" || blockType == "file" {
		return ""
	}
	safe := sanitizeInline(content)
	return truncateRunes(safe, maxContentRunes)
}

func normalizeProps(blockType string, props BlockProps) BlockProps {
	props.Icon = truncateRunes(strings.TrimSpace(props.Icon), 16)
	if props.Icon == "" && blockType == "callout" {
		props.Icon = "💡"
	}
	if !blockColors[props.Color] {
		props.Color = "default"
	}
	props.Language = truncateRunes(strings.TrimSpace(props.Language), 20)
	if props.Language == "" && blockType == "code" {
		props.Language = "text"
	}
	props.Caption = truncateRunes(strings.TrimSpace(props.Caption), 500)
	props.URL = truncateRunes(strings.TrimSpace(props.URL), 2000)
	if props.URL != "" && !safeAssetURL(props.URL) {
		props.URL = ""
	}
	if blockType == "table" {
		rows := props.Rows
		if len(rows) == 0 {
			rows = [][]string{{"", "", ""}, {"", "", ""}, {"", "", ""}}
		}
		if len(rows) > 20 {
			rows = rows[:20]
		}
		for i := range rows {
			if len(rows[i]) > 10 {
				rows[i] = rows[i][:10]
			}
			for j := range rows[i] {
				rows[i][j] = truncateRunes(strings.TrimSpace(rows[i][j]), 500)
			}
		}
		props.Rows = rows
	} else {
		props.Rows = nil
		props.HasHeader = false
	}
	return props
}

func normalizeTitle(title string) string {
	title = strings.TrimSpace(strings.ReplaceAll(title, "\n", " "))
	return truncateRunes(title, 200)
}

func normalizeIcon(icon string) string {
	return truncateRunes(strings.TrimSpace(icon), 16)
}

// normalizeCover 只接受内置渐变色与本地/远程图片地址。
func normalizeCover(cover string) string {
	cover = strings.TrimSpace(cover)
	if cover == "" {
		return ""
	}
	if strings.HasPrefix(cover, "gradient:") {
		return truncateRunes(cover, 200)
	}
	if safeAssetURL(cover) {
		return truncateRunes(cover, 2000)
	}
	return ""
}

func summarize(page Page) PageSummary {
	preview := ""
	for _, block := range page.Blocks {
		text := blockPlainText(block)
		if text != "" {
			preview = truncateRunes(text, 120)
			break
		}
	}
	return PageSummary{
		ID:         page.ID,
		ParentID:   page.ParentID,
		Title:      page.Title,
		Icon:       page.Icon,
		Cover:      page.Cover,
		Folder:     page.Folder,
		Favorite:   page.Favorite,
		Trashed:    page.Trashed,
		TrashedAt:  page.TrashedAt,
		Order:      page.Order,
		BlockCount: len(page.Blocks),
		Preview:    preview,
		CreatedAt:  page.CreatedAt,
		UpdatedAt:  page.UpdatedAt,
	}
}

func sortedPages(pages []Page) []Page {
	out := make([]Page, len(pages))
	copy(out, pages)
	sort.SliceStable(out, func(i, j int) bool {
		if out[i].ParentID == out[j].ParentID {
			if out[i].Order == out[j].Order {
				return out[i].CreatedAt < out[j].CreatedAt
			}
			return out[i].Order < out[j].Order
		}
		return out[i].ParentID < out[j].ParentID
	})
	return out
}

func blockPlainText(block Block) string {
	switch block.Type {
	case "code":
		return strings.TrimSpace(block.Content)
	case "table":
		var parts []string
		for _, row := range block.Props.Rows {
			for _, cell := range row {
				if cell != "" {
					parts = append(parts, cell)
				}
			}
		}
		return strings.Join(parts, " ")
	case "image", "bookmark", "audio", "video", "file":
		return strings.TrimSpace(block.Props.Caption)
	default:
		return plainText(block.Content)
	}
}

func pageFiles(page Page) []string {
	var out []string
	add := func(value string) {
		if rel := assetRelPath(value); rel != "" {
			out = append(out, rel)
		}
	}
	add(page.Cover)
	for _, block := range page.Blocks {
		switch block.Type {
		case "image", "audio", "video", "file":
			add(block.Props.URL)
		}
	}
	return out
}

func cloneBlocks(blocks []Block) []Block {
	out := make([]Block, len(blocks))
	for i, block := range blocks {
		out[i] = block
		if block.Props.Rows != nil {
			rows := make([][]string, len(block.Props.Rows))
			for j, row := range block.Props.Rows {
				rows[j] = append([]string(nil), row...)
			}
			out[i].Props.Rows = rows
		}
	}
	return out
}

func makeSnippet(text, query string) string {
	byteIndex := strings.Index(strings.ToLower(text), strings.ToLower(query))
	if byteIndex < 0 {
		return truncateRunes(text, 140)
	}
	runes := []rune(text)
	index := utf8.RuneCountInString(text[:byteIndex])
	start := index - 40
	if start < 0 {
		start = 0
	}
	end := index + utf8.RuneCountInString(query) + 80
	if end > len(runes) {
		end = len(runes)
	}
	part := string(runes[start:end])
	if start > 0 {
		part = "…" + part
	}
	if end < len(runes) {
		part += "…"
	}
	return strings.TrimSpace(part)
}

// 行内标签白名单与清洗规则。
var (
	tagPattern    = regexp.MustCompile(`(?s)<[^>]*>`)
	hrefPattern   = regexp.MustCompile(`(?i)\bhref\s*=\s*("([^"]*)"|'([^']*)')`)
	allowedTags   = map[string]bool{"b": true, "strong": true, "i": true, "em": true, "u": true, "s": true, "strike": true, "del": true, "code": true, "a": true, "br": true, "mark": true}
	mdLinkPattern = regexp.MustCompile(`(?s)<a href="([^"]*)">(.*?)</a>`)
)

// sanitizeInline 只保留编辑器需要的行内标签，避免注入脚本与样式。
func sanitizeInline(raw string) string {
	var out strings.Builder
	last := 0
	for _, loc := range tagPattern.FindAllStringIndex(raw, -1) {
		out.WriteString(raw[last:loc[0]])
		out.WriteString(cleanTag(raw[loc[0]:loc[1]]))
		last = loc[1]
	}
	out.WriteString(raw[last:])
	return out.String()
}

func cleanTag(tag string) string {
	body := strings.TrimSuffix(strings.TrimPrefix(strings.TrimSpace(tag), "<"), ">")
	body = strings.TrimSpace(body)
	closing := strings.HasPrefix(body, "/")
	body = strings.TrimPrefix(body, "/")
	body = strings.TrimSpace(strings.TrimSuffix(body, "/"))
	name := body
	if i := strings.IndexAny(name, " \t\r\n"); i >= 0 {
		name = name[:i]
	}
	name = strings.ToLower(name)
	if !allowedTags[name] {
		return ""
	}
	if name == "br" {
		return "<br>"
	}
	if closing {
		if name == "br" {
			return ""
		}
		return "</" + name + ">"
	}
	if name == "a" {
		if m := hrefPattern.FindStringSubmatch(tag); m != nil {
			href := m[2]
			if href == "" {
				href = m[3]
			}
			if safeURL(href) {
				return `<a href="` + html.EscapeString(href) + `">`
			}
		}
		return ""
	}
	return "<" + name + ">"
}

func safeURL(value string) bool {
	value = strings.TrimSpace(strings.ToLower(value))
	if value == "" {
		return false
	}
	if strings.HasPrefix(value, "http://") || strings.HasPrefix(value, "https://") || strings.HasPrefix(value, "mailto:") {
		return true
	}
	return false
}

// safeAssetURL 额外允许插件自身上传的附件地址。
func safeAssetURL(value string) bool {
	value = strings.TrimSpace(value)
	if strings.HasPrefix(value, "/api/apps/notes/files/") || strings.HasPrefix(value, "files/") {
		return assetRelPath(value) != ""
	}
	return safeURL(value)
}

func plainText(value string) string {
	text := tagPattern.ReplaceAllString(value, " ")
	text = html.UnescapeString(text)
	return strings.TrimSpace(strings.Join(strings.Fields(text), " "))
}

// inlineToMarkdown 将受控的行内 HTML 转换为 Markdown。
func inlineToMarkdown(value string) string {
	value = mdLinkPattern.ReplaceAllString(value, "[$2]($1)")
	value = strings.NewReplacer(
		"<br>", "  \n",
		"<strong>", "**", "</strong>", "**",
		"<b>", "**", "</b>", "**",
		"<em>", "*", "</em>", "*",
		"<i>", "*", "</i>", "*",
		"<del>", "~~", "</del>", "~~",
		"<s>", "~~", "</s>", "~~",
		"<strike>", "~~", "</strike>", "~~",
		"<code>", "`", "</code>", "`",
		"<mark>", "==", "</mark>", "==",
	).Replace(value)
	value = tagPattern.ReplaceAllString(value, "")
	return html.UnescapeString(value)
}

func exportMarkdown(page Page) string {
	var out strings.Builder
	title := page.Title
	if title == "" {
		title = "Untitled"
	}
	out.WriteString("# " + strings.ReplaceAll(title, "\n", " ") + "\n\n")
	for _, block := range page.Blocks {
		text := inlineToMarkdown(block.Content)
		switch block.Type {
		case "heading1":
			out.WriteString("# " + text + "\n\n")
		case "heading2":
			out.WriteString("## " + text + "\n\n")
		case "heading3":
			out.WriteString("### " + text + "\n\n")
		case "bulleted":
			out.WriteString("- " + text + "\n")
		case "numbered":
			out.WriteString("1. " + text + "\n")
		case "todo":
			if block.Props.Checked {
				out.WriteString("- [x] " + text + "\n")
			} else {
				out.WriteString("- [ ] " + text + "\n")
			}
		case "toggle":
			out.WriteString("- " + text + "\n")
		case "quote":
			out.WriteString("> " + text + "\n\n")
		case "callout":
			out.WriteString("> " + block.Props.Icon + " " + text + "\n\n")
		case "code":
			lang := block.Props.Language
			if lang == "text" {
				lang = ""
			}
			out.WriteString("```" + lang + "\n" + block.Content + "\n```\n\n")
		case "divider":
			out.WriteString("---\n\n")
		case "equation":
			src := strings.TrimSpace(block.Content)
			if strings.Contains(src, "\n") {
				out.WriteString("$$\n" + src + "\n$$\n\n")
			} else {
				out.WriteString("$$" + src + "$$\n\n")
			}
		case "diagram":
			out.WriteString("```mermaid\n" + block.Content + "\n```\n\n")
		case "image":
			out.WriteString("![" + block.Props.Caption + "](" + block.Props.URL + ")\n\n")
		case "audio":
			out.WriteString("<audio controls src=\"" + block.Props.URL + "\"></audio>\n\n")
		case "video":
			out.WriteString("<video controls src=\"" + block.Props.URL + "\"></video>\n\n")
		case "file":
			label := block.Props.Caption
			if label == "" {
				label = block.Props.URL
			}
			out.WriteString("[" + label + "](" + block.Props.URL + ")\n\n")
		case "bookmark":
			label := block.Props.Caption
			if label == "" {
				label = block.Props.URL
			}
			out.WriteString("[" + label + "](" + block.Props.URL + ")\n\n")
		case "table":
			out.WriteString(tableMarkdown(block))
		default:
			if text != "" {
				out.WriteString(text + "\n\n")
			}
		}
	}
	return strings.TrimRight(out.String(), "\n") + "\n"
}

func tableMarkdown(block Block) string {
	rows := block.Props.Rows
	if len(rows) == 0 {
		return ""
	}
	var out strings.Builder
	for i, row := range rows {
		out.WriteString("|")
		for _, cell := range row {
			out.WriteString(" " + strings.ReplaceAll(cell, "|", `\|`) + " |")
		}
		out.WriteString("\n")
		if i == 0 && block.Props.HasHeader {
			out.WriteString("|")
			for range row {
				out.WriteString(" --- |")
			}
			out.WriteString("\n")
		}
	}
	out.WriteString("\n")
	return out.String()
}

// migrateLegacy 把历史上的 notes.json 导入数据库，成功后保留 .bak 备份。
func (p *API) migrateLegacy(path string) error {
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil
		}
		return err
	}
	var count int
	if err := p.db.QueryRow("SELECT COUNT(*) FROM pages").Scan(&count); err != nil {
		return err
	}
	if count == 0 {
		plain, err := p.keys.DecryptBytes(data)
		if err != nil {
			return fmt.Errorf("解密笔记数据失败: %w", err)
		}
		var ws Workspace
		if err := json.Unmarshal(plain, &ws); err != nil {
			return fmt.Errorf("解析笔记数据失败: %w", err)
		}
		p.ws = ws
		p.normalizeWorkspace()
		pages := p.ws.Pages
		p.ws = Workspace{}
		if err := p.savePages(pages...); err != nil {
			return err
		}
	}
	if err := sqlstore.BackupLegacy(path); err != nil && p.log != nil {
		p.log.Warn("备份历史笔记数据失败", "err", err)
	}
	return nil
}

// loadWorkspace 从数据库读取全部页面与块。
func (p *API) loadWorkspace() error {
	rows, err := p.db.Query("SELECT " + pageColumns + " FROM pages ORDER BY parent_id, ord, created_at")
	if err != nil {
		return err
	}
	pages := make([]Page, 0, 16)
	index := make(map[string]int, 16)
	for rows.Next() {
		var page Page
		var folder, favorite, trashed int
		if err := rows.Scan(&page.ID, &page.ParentID, &page.Title, &page.Icon, &page.Cover,
			&folder, &favorite, &trashed, &page.TrashedAt, &page.Order,
			&page.CreatedAt, &page.UpdatedAt); err != nil {
			rows.Close()
			return err
		}
		page.Folder = folder != 0
		page.Favorite = favorite != 0
		page.Trashed = trashed != 0
		page.Blocks = []Block{}
		if page.Title, err = p.keys.Decrypt(page.Title); err != nil {
			rows.Close()
			return fmt.Errorf("解密笔记标题失败: %w", err)
		}
		index[page.ID] = len(pages)
		pages = append(pages, page)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return err
	}
	rows.Close()

	blockRows, err := p.db.Query("SELECT page_id, id, type, content, props_json FROM blocks ORDER BY page_id, ord")
	if err != nil {
		return err
	}
	defer blockRows.Close()
	for blockRows.Next() {
		var pageID string
		var block Block
		var propsJSON string
		if err := blockRows.Scan(&pageID, &block.ID, &block.Type, &block.Content, &propsJSON); err != nil {
			return err
		}
		if block.Content, err = p.keys.Decrypt(block.Content); err != nil {
			return fmt.Errorf("解密笔记内容失败: %w", err)
		}
		if propsJSON, err = p.keys.Decrypt(propsJSON); err != nil {
			return fmt.Errorf("解密笔记块属性失败: %w", err)
		}
		if propsJSON != "" && propsJSON != "{}" {
			if err := json.Unmarshal([]byte(propsJSON), &block.Props); err != nil {
				return fmt.Errorf("解析笔记块属性失败: %w", err)
			}
		}
		if i, ok := index[pageID]; ok {
			pages[i].Blocks = append(pages[i].Blocks, block)
		}
	}
	if err := blockRows.Err(); err != nil {
		return err
	}

	p.ws = Workspace{Pages: pages}
	if p.ws.Pages == nil {
		p.ws.Pages = []Page{}
	}
	return nil
}

// savePages 在事务中写入页面及其全部块，用于单页编辑与局部变更。
func (p *API) savePages(pages ...Page) error {
	if len(pages) == 0 {
		return nil
	}
	tx, err := p.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()
	pageStmt, err := tx.Prepare(upsertPage)
	if err != nil {
		return err
	}
	defer pageStmt.Close()
	blockStmt, err := tx.Prepare(insertBlock)
	if err != nil {
		return err
	}
	defer blockStmt.Close()
	for _, page := range pages {
		title, err := p.keys.Encrypt(page.Title)
		if err != nil {
			return err
		}
		if _, err := pageStmt.Exec(page.ID, page.ParentID, title, page.Icon, page.Cover,
			b2i(page.Folder), b2i(page.Favorite), b2i(page.Trashed), page.TrashedAt,
			page.Order, page.CreatedAt, page.UpdatedAt); err != nil {
			return err
		}
		if _, err := tx.Exec("DELETE FROM blocks WHERE page_id = ?", page.ID); err != nil {
			return err
		}
		for i, block := range page.Blocks {
			content, err := p.keys.Encrypt(block.Content)
			if err != nil {
				return err
			}
			props, err := json.Marshal(block.Props)
			if err != nil {
				return err
			}
			propsEnc, err := p.keys.Encrypt(string(props))
			if err != nil {
				return err
			}
			if _, err := blockStmt.Exec(page.ID, block.ID, i, block.Type, content, propsEnc); err != nil {
				return err
			}
		}
	}
	return tx.Commit()
}

// deletePages 删除页面，块由外键级联清理。
func (p *API) deletePages(ids []string) error {
	if len(ids) == 0 {
		return nil
	}
	tx, err := p.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()
	stmt, err := tx.Prepare("DELETE FROM pages WHERE id = ?")
	if err != nil {
		return err
	}
	defer stmt.Close()
	for _, id := range ids {
		if _, err := stmt.Exec(id); err != nil {
			return err
		}
	}
	return tx.Commit()
}

func b2i(v bool) int {
	if v {
		return 1
	}
	return 0
}

func newID() string {
	buf := make([]byte, 8)
	_, _ = rand.Read(buf)
	return hex.EncodeToString(buf)
}

var idPattern = regexp.MustCompile(`^[a-zA-Z0-9_-]{4,64}$`)

func validID(id string) bool { return idPattern.MatchString(id) }

func nowString() string { return time.Now().Format(time.RFC3339) }

func truncateRunes(text string, limit int) string {
	runes := []rune(text)
	if len(runes) <= limit {
		return text
	}
	return string(runes[:limit])
}

func safeFilename(title string) string {
	name := strings.TrimSpace(title)
	if name == "" {
		name = "note"
	}
	name = strings.NewReplacer("/", "_", "\\", "_", ":", "_", "*", "_", "?", "_", `"`, "_", "<", "_", ">", "_", "|", "_").Replace(name)
	return truncateRunes(name, 80)
}

func encodeFilename(name string) string {
	var out strings.Builder
	for _, b := range []byte(name) {
		if (b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z') || (b >= '0' && b <= '9') || b == '.' || b == '-' || b == '_' {
			out.WriteByte(b)
			continue
		}
		out.WriteString("%" + strings.ToUpper(hex.EncodeToString([]byte{b})))
	}
	return out.String()
}
