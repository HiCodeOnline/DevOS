# DevOS 应用锁、国际化与设置面板实施计划

## Context

DevOS 目前启动后直接进入桌面，没有任何访问控制；界面文案全部硬编码为简体中文；也没有统一的应用设置入口。本次需要实现三件事：

1. **应用锁**：像手机一样，启动时必须输入应用密码才能进入桌面；进入后可手动「立即锁定」。
2. **国际化**：支持简体中文、English、繁体中文，词典结构可低成本扩展其它语言。本期范围限定为桌面外壳、开始菜单、锁屏、设置面板与共享弹窗，六个内置应用页面暂不迁移（约 3000 处文案，后续按同一机制逐步接入）。
3. **设置面板**：壁纸（内置预设 + 本地上传）、语言切换、应用密码管理（首次设置；修改/移除必须先验证旧密码）。

已确认的产品决策：锁定时机为「启动锁 + 手动锁定」；密码为任意字符、至少 6 位；壁纸支持预设与本地上传。锁屏与鉴权必须在后端生效，不能只做前端遮罩，否则直接访问 `/apps/...` 或 `/api/...` 即可绕过。

## 方案概览

### 1. 后端：安全存储与会话（新增 `internal/security`）

- `internal/security/store.go`
  - 数据文件 `{dataDir}/security.json`，权限 `0600`，原子写（`CreateTemp` → `Chmod` → `Sync` → `Rename`），`sync.Mutex` 保护。
  - `Settings` 字段：`Salt`、`Hash`、`Params`（N/r/p）、`Locale`、`Wallpaper`（`{kind:"preset"|"custom", preset, file}`）。
  - 方法：`SetPassword`、`VerifyPassword`、`ChangePassword`、`RemovePassword`、`HasPassword`、`SetLocale`、`SetWallpaper`、`Load`。
- `internal/security/hash.go`
  - scrypt `N=32768, r=8, p=1, keyLen=32`，16 字节随机 salt，`subtle.ConstantTimeCompare`。
  - 不复用 `secure.normalizePassword`（它用于导出密钥，会大写且要求 ≥16）；新实现只校验 `len([]rune) >= 6`，不做归一化。
  - 校验参数上限（N ≤ 1<<20、r ≤ 32、p ≤ 8）防止损坏文件导致资源耗尽；`Verify` 用容量 1 的信号量串行化。
- `internal/security/session.go`
  - 32 字节随机 token（base64url），内存 `map[token]expiry`；不落盘，进程重启即失效。
  - Cookie：`devos_session`，`Path=/`、`HttpOnly`、`SameSite=Strict`、不设 MaxAge。
  - 连续失败计数 + 指数退避（1s → 30s），防止暴力猜测。

### 2. 后端：内核鉴权与设置 API

- `internal/kernel/kernel.go`
  - `Kernel` 增加 `security *security.Store`、`sessions *security.Sessions`；`New()` 中加载 `security.json`（损坏时报错退出，避免静默降级）。
  - `routes()` **第一条**注册 `app.Use(k.securityGuard)`，早于所有 API、`/apps/*`、`/mock` 与末尾 `/` 静态资源，避免与现有 `app.Use("/apps/"+m.ID, ...)`、`/apps/:appId` 的顺序耦合。
- `internal/kernel/security_guard.go`
  - 未设置密码 → 全部放行。
  - 已设置密码且会话无效时：`/api/*` 返回 401 JSON；`/apps*`、`/mock*` 返回 401；`/`、`/assets/*`、`/favicon.ico` 放行（锁屏需要）。
  - 放行 `/api/health`、`/api/security/status`、`/api/security/unlock`、`/api/security/wallpaper/file/*`。
- `internal/kernel/security_api.go`
  - `GET /api/security/status`：`{hasPassword, locked, locale, wallpaper}`，不泄露 hash/salt。
  - `POST /api/security/unlock`：校验密码，成功下发 cookie（密码修改后旧会话全部失效）。
  - `POST /api/security/lock`：清除当前 token。
  - `POST /api/security/password`：`{oldPassword,newPassword}`；首次设置可不填旧密码，修改/移除必须校验旧密码；成功后清空全部会话并重新签发。
  - `POST /api/security/settings`：更新 `locale`、预设壁纸。
  - `POST /api/security/wallpaper`：multipart 上传；限制 8MB；`image.DecodeConfig` 校验 PNG/JPEG/WebP，拒绝 SVG；文件名由服务端生成；保存到 `{dataDir}/wallpapers/`，替换时删除旧文件。
  - `GET /api/security/wallpaper/file/:name`：正则白名单 + `filepath.Base` + 目录内校验，`X-Content-Type-Options: nosniff`。
  - 所有非 GET 的 `/api/security/*` 校验 `X-DevOS-Request: 1` 与同源 `Origin`，降低 CSRF 风险。

### 3. 前端：i18n 基础设施

- `web/assets/i18n.js`
  - `window.DevOSI18n`：`register(locale, dict)`、`t(key, params)`（`{name}` 插值，缺失回退 zh-CN → key）、`setLocale`（写 `localStorage.devos.locale`、更新 `html[lang]`、派发 `devos:locale-changed`）、`apply(root)` 处理 `data-i18n` / `data-i18n-placeholder` / `data-i18n-title`。
- `web/assets/locales/zh-CN.js`、`en.js`、`zh-TW.js`：同步脚本注册，避免 fetch 造成的文案闪烁。
  - 键采用点分命名空间：`desktop.*`、`start.*`、`lock.*`、`settings.*`、`common.*`，预留 `apps.<id>.*` 给后续应用页面。
- `secure-ui.js` 改为优先使用 `DevOSI18n.t()`，未加载时回退中文。

### 4. 前端：锁屏与启动流程

- `web/index.html`
  - 新增全屏 `#lockScreen`（壁纸背景、密码输入、错误提示、语言快切、解锁按钮）。
  - 开始菜单底部新增操作区：`#openSettings`（设置）、`#lockNow`（立即锁定）。
  - 引入顺序：`i18n.js` → locales → `lock.css`/`settings.css` → `lock.js`/`settings.js`，版本号递增。
- `web/assets/desktop.js`
  - 拆分 `boot()`：先渲染时钟与 i18n，再请求 `/api/security/status`。
  - `hasPassword` 且未解锁 → 显示锁屏并隐藏 `#desktop`/`#taskbar`，**不加载应用列表**；解锁成功后才执行原 `loadApps()` 流程。
  - 锁定动作：调用 `POST /api/security/lock`，关闭/置空所有 iframe（`about:blank`），隐藏桌面与任务栏。
  - 暴露 `window.DevOSDesktop = { start }` 供锁屏解锁后回调。
  - `renderClock`、开始菜单、`renderStatus`、toast 等文案改用 `t()`；开始菜单新增设置/锁定入口。
- `web/assets/lock.js` + `lock.css`：Enter 提交、自动聚焦、错误与退避倒计时提示、语言切换即时生效、锁屏状态下禁用桌面快捷键。
- `web/assets/settings.js` + `settings.css`
  - 原生 overlay（非 iframe），三个分区：外观（壁纸预设网格 + 本地上传 + 预览）、语言（三选一）、安全（设置/修改/移除密码）。
  - 修改与移除密码都要求输入旧密码；首次设置隐藏旧密码框；前端做「至少 6 位」「两次新密码一致」校验，后端做最终校验。
  - 壁纸与语言成功后立即应用并持久化。

### 5. 样式

- `desktop.css`：壁纸预设类（渐变/纯色）、锁屏与设置面板共用的遮罩、输入框、按钮样式；选中态继续沿用中性灰，不使用系统蓝。
- `settings.css` / `lock.css`：遵循 Tailwind 官网首页的设计语言与现有 `ui.css` 控件规范。

## 实施步骤

1. **安全存储**：新增 `internal/security/{hash,store,session}.go` 与对应测试；`go test ./internal/security/`。
2. **内核鉴权**：改造 `kernel.New`，新增 `security_guard.go`、`security_api.go`，`routes()` 首行注册中间件；补鉴权与 API 测试。
3. **i18n 基础设施**：新增 `i18n.js` 与三份词典，改造 `index.html`/`desktop.js` 文案与时钟本地化。
4. **锁屏**：新增 `lock.js`/`lock.css`，拆分启动流程，验证启动锁定、错误密码、解锁、立即锁定。
5. **设置面板**：新增 `settings.js`/`settings.css` 与开始菜单入口，完成壁纸预设、语言、密码三项。
6. **壁纸上传**：实现上传/读取 API 与前端预览上传，补路径穿越与类型校验测试。
7. **共享弹窗 i18n**：`secure-ui.js` 接入 `DevOSI18n`，并做全量回归。
8. 版本号更新（`index.html` 中的 `?v=`）避免浏览器缓存旧资源。

## 验证

- **单元测试**：`internal/security`（设置/校验/修改/移除、错误旧密码、短密码、持久化、损坏 JSON、并发）、`internal/kernel`（无密码放行；锁定后 `/api/apps` 401、`/api/health` 200、`/assets` 200、`/apps/*` 401、`/mock/*` 401；解锁 cookie 生效；密码修改后旧 cookie 失效；缺 `X-DevOS-Request`/伪造 Origin 拒绝）、壁纸上传（合法 PNG、伪装文本、SVG、超限、路径穿越、旧文件清理）。
- **接口验证**：用 PowerShell `curl.exe` 依次验证 status/unlock/lock/password/settings/wallpaper，确认错误密码 401/退避、正确密码下发 cookie、修改后旧 cookie 失效。
- **浏览器验证**：
  1. 首次启动无密码 → 直接进入桌面。
  2. 设置密码 → 立即锁定 → 锁屏出现，错误密码提示，正确密码进入。
  3. 重启应用（`devos.exe`）→ 仍显示锁屏。
  4. 锁屏状态下直接访问 `/apps/db/index.html` 与 `/api/apps` → 被拦截。
  5. 修改语言为 English / 繁體中文 → 桌面、开始菜单、锁屏、设置立即切换，重启后保持。
  6. 选择预设壁纸与上传本地图片 → 锁屏与桌面均生效，重启后保持。
  7. 修改密码需旧密码；移除密码需旧密码；移除后重启直接进入桌面。

## 主要涉及文件

- 新增：`internal/security/store.go`、`hash.go`、`session.go`、`internal/kernel/security_guard.go`、`security_api.go`、`web/assets/i18n.js`、`locales/*.js`、`lock.js`、`settings.js`、`lock.css`、`settings.css`
- 修改：`internal/kernel/kernel.go`、`main.go`（如需传递安全存储）、`web/index.html`、`web/assets/desktop.js`、`web/assets/desktop.css`、`web/assets/secure-ui.js`
- 参考复用：`internal/secure/secure.go`（随机数与加密惯例）、`internal/plugins/db/db_test.go`（Fiber `app.Test` 测试写法）、`web/assets/secure-ui.js`（overlay 弹窗模式）

## 说明与限制

- 会话只存内存，重启进程后需要重新解锁；这是有意设计。
- 应用密码哈希与 `security.json` 分离于各应用的加密密钥；忘记密码时无法通过旧密码移除，只能手动删除 `security.json` 中的密码字段（会在文档中注明）。
- Windows 上 `0600` 权限仅作提示，不提供 Unix 式强制隔离。
